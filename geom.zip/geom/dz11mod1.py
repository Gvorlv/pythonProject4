def dlst(a, b): #расчет длин сторон прямоугольника
    return a*2+b*2
def plpr(a, b): #расчет площади прямоугольника
    return a*b
def plkub(a): #расчет объема куба
    return a**3
def plkub(a): #расчет площади куба
    return 6*(a**2)


